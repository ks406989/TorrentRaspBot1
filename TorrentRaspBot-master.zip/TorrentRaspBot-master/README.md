# TorrentRaspBot
Telegram Bot capable of managing Torrent files and auto auploading to Google Drive

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Vijay62/TorrentRaspBot/tree/master)
