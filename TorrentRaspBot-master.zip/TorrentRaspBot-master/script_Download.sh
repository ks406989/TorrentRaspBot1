#!/bin/bash
wget -o ~/log_wget.txt -O Super_Secret_File $1 #We download the file
mv Super_Secret_File ~  #We move to home