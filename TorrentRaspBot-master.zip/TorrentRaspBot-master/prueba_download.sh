#!/bin/bash
wget $1